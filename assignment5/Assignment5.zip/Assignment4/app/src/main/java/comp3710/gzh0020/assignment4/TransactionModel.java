package comp3710.gzh0020.assignment4;

public class TransactionModel {
    public String mDate, mItem;
    public double mPrice;
}
