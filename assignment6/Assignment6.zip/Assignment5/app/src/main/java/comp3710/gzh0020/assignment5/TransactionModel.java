package comp3710.gzh0020.assignment5;

public class TransactionModel {
    public String mDate, mItem;
    public double mPrice;
}